/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BinarySearch;

class BinarySearch(A,l,r,key){
    if(l==r){
    if(A[l]==key){
        return l+1;
    }
    else if{
        return -1;
    }
   }
    else{
    m=[(l+r)/2]
    if(A[m]==key){
        return m+1;
    }
    else if(A[m]<key){
        return BinarySearch(A,m+1,r,key);
    }
    else{
        return BinarySearch(A,l,m-1,key);
    }
}
}

public class BinarySearch {
    BinarySearch b= new BinarySearch()
}
