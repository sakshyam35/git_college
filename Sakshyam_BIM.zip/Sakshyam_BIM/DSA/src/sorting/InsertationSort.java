
package sorting;

import java.util.Scanner;

public class InsertationSort {
    static int A[] = new int[100];
    static int n;
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of the array????");
        n = sc.nextInt();
        
        System.out.println("Enter element of the array ????");
        
        for(int i = 0;i<n; i++){
        System.out.println("A["+i+"] :");
        A[i]=sc.nextInt();
        }
        
        System.out.println("Data before sorting: ");
        System.out.println("**********************");
        display();
        insertationSort();
        System.out.println("Data after sorting: ");
        System.out.println("**********************");
        display();
    }
    public static void insertationSort()
    {
         int key=0, j=0;
        for(int i= 1; i<n; i++){
            key = A[i];
            
           for(j = i+1; j>=0 && A[j]>key; j-- ) {
               A[j+1] = A[j];
           }
           A[j+1]=key;
        }
          
           
    }
       
    public static void display(){
        for(int i = 0; i< n; i++){
            System.out.println(A[i]+ "\t");
        }
    }
}
