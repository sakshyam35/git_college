package sorting;

import java.util.Scanner;

import java.util.Scanner;

public class HeapSort {
    static int A[] = new int[100];
    static int n, n1;
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of the array????");
        n = sc.nextInt();
        n1 = n;
        
        System.out.println("Enter element of the array ????");
        
        for(int i = 1; i<n; i++){
        System.out.println("A["+i+"] :");
        A[i]=sc.nextInt();
        }
        
        System.out.println("Data before sorting: ");
        System.out.println("**********************");
        display();
        heapSort();
        System.out.println("Data after sorting: ");
        System.out.println("**********************");
        display();
    }
    public static void heapSort()
    {
         MAX_HEAP_BUILT();
         for(int i = n1; i>= 2; i--){
             int temp = A[1];
             A[1] = A[n1];
             A[n1] = temp;
             n1--;
             Heapify(i);
         }
    }
       
    public static void display(){
        for(int i = 1; i< n; i++){
            System.out.println(A[i]+ "\t");
        }
    }
    
    public static void MAX_HEAP_BUILT(){
        for(int i = n1/2; i>1; i--){
            Heapify(i);
        }
    }
    
    public static void Heapify(int i){
        int l = 2*i;
        int r= 2*i+1;
        int largest = i;
        if(l<=n1 && A[l]>A[largest])
            largest =l;
        if(r<=n1 && A[r]>A[largest])
            largest =r;
        if(i!=largest)
        {
            int temp = A[i];
            A[i] = A[largest];
            A[largest] = temp;
            n1--;
            Heapify(largest);
        }
    }
}
