/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Queue;

import javax.swing.JOptionPane;

public class CircularQueueDemo {
    public static void main(String[] args){
        CircularQueue cq = new CircularQueue();
        cq.enqueue(100);
        cq.enqueue(200);
        cq.enqueue(300);
        cq.printQueue();
        cq.dequeue();
        cq.printQueue();
    } 
}

class CircularQueue
{
    final int MAXSIZE =10;
    int front = MAXSIZE-1;
    int rear = MAXSIZE-1;
    int Item[] = new int[MAXSIZE] ;
    
    
    public boolean isEmpty()
    {
        if(rear==front)
            return true;
        else
            return false;
    }
    
    public boolean isFull()
    {
        if(front==(rear+1)%MAXSIZE)
            return true;
        else
            return false;
    }
    
    public void enqueue(int data)
    {
        if(isFull())
        {
            JOptionPane.showMessageDialog(null,"Queue is full" );
        }
        else
        {
            rear=(rear+1)%MAXSIZE;
            Item[rear]=data;
        }
    }
    
    public void dequeue()
    {
        if(isEmpty())
        {
            JOptionPane.showMessageDialog(null,"Nothing to delete" );
        }
        else
        {
           front = (front+1)%MAXSIZE;
           int data = Item[front];
           Item[front]= -1;
           JOptionPane.showMessageDialog(null,"Data being deleted:" +data );
        }
    }
    
    public void printQueue()
    {
        String str="[";
        for(int i=0; i<Item.length; i++){
            str +=" " +Item[i];
        }
        str +="]";
        JOptionPane.showMessageDialog(null,str);
        
    }
}

