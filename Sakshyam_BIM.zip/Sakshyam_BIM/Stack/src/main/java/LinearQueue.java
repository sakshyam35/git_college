
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Students
 */
public class LinearQueue {
    public static void main(String[]args){
        Queue q= new Queue();
                q.enqueue(100);
                q.enqueue(200);
                q.enqueue(300);
                q.enqueue(400);
                q.printQueue();
                q.dequeue();
                q.dequeue();
                q.printQueue();              
        
    }
    
}
class Queue
{
    final int MAXSIZE = 10;
    int A[] = new int[MAXSIZE];
    int front=0;
    int rear = -1;
    public boolean isEmpty()
    {
        if(rear<front)
        {
            return true;
        }
        else
            return false;
    }
    public boolean isFull()
    {
        if(rear==MAXSIZE-1){
           return true;
        }
        return false;
    }
    public void enqueue()
    {
        if(isFull())
        {
            System.out.println("Queue is already full");
        }
        else
        {
            rear++;
            A[rear]=data;
        }
    }
    public void dequeue()
    {
        if(isEmpty())
        {
            System.out.println("Nothing to delete");
        }
        else
        {
            int data = A[front];
            front++;
            JOptionPane.ShowMessageDialog(null,"Data being delete:" +data);
        }
    }
    public void printQueue()
    {
        String str="[";
        for(int i=0; i<A.length; i++){
            str +=" " +A[i];
        }
        str +="]";
        JOptionPane.showMessageDialog(null,str);
        
    }
}

